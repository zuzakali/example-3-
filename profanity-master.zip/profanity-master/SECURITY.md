# Security Policy

## Reporting a Vulnerability

Security vulnerabilities should be reported via email or xmpp to:

* <jubalh@iodoru.org> (6F88C537A25E481489574956E3370C9A9A55BF71)
