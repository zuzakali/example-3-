# Giving back

Thank you very much to all of our sponsors and donors (including those that want to stay private)!

## Sponsors
[Martin Dosch](https://github.com/mdosch) since January 2020

[Alexander Dahl](https://github.com/LeSpocky) since January 2021

[James Pond](https://github.com/jamesponddotco) since February 2021

## Donors
[Martin Dosch](https://github.com/mdosch)

[Julian Huhn](https://github.com/huhndev)

[Matteo Bini](https://github.com/matteobin)

## Services
[Stefan Kropp](https://github.com/StefanKropp) for sponsoring our [mailing list](https://lists.posteo.de/listinfo/profanity)

[dismail](https://dismail.de/) for hosting our [MUC](xmpp:profanity@rooms.dismail.de?join)
