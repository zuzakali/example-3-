void rooms_query(void **state);
