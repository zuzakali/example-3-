void connect_jid_requests_roster(void **state);
void connect_jid_sends_presence_after_receiving_roster(void **state);
void connect_jid_requests_bookmarks(void **state);
void connect_bad_password(void **state);
void connect_shows_presence_updates(void **state);
