int muc_before_test(void** state);
int muc_after_test(void** state);

void test_muc_invites_add(void** state);
void test_muc_remove_invite(void** state);
void test_muc_invites_count_0(void** state);
void test_muc_invites_count_5(void** state);
void test_muc_room_is_not_active(void** state);
void test_muc_active(void** state);
