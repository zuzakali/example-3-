void statuses_console_defaults_to_all(void** state);
void statuses_chat_defaults_to_all(void** state);
void statuses_muc_defaults_to_all(void** state);
