void clears_chat_sessions(void** state);
