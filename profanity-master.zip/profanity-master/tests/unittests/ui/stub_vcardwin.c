void
vcardwin_update(void)
{
}
